// export const base_url = `${window.location.origin}:3001/`;
// export const base_url = `${window.location.origin}/backend/`;
// export const base_url = `http://localhost:2222/`;
// export const base_url = `https://dev.jobs.outbooks.com/backend/`;
// export const base_url = `https://jobs.outbooks.com/backend/`;


const isLocalhost = window.location.hostname === "localhost";
export const base_url = isLocalhost
? "http://localhost:2222/"
: `${window.location.origin}/backend/`;